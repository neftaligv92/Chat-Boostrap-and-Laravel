-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb2+deb7u2
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 07-08-2018 a las 23:34:30
-- Versión del servidor: 5.5.47
-- Versión de PHP: 5.4.45-0+deb7u2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `db_creating`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cw_users`
--

CREATE TABLE IF NOT EXISTS `cw_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(20) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `age` varchar(2) NOT NULL,
  `sex` varchar(1) NOT NULL,
  `priv` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Volcado de datos para la tabla `cw_users`
--

INSERT INTO `cw_users` (`id`, `user`, `pass`, `email`, `age`, `sex`, `priv`) VALUES
(1, 'AlleN_WalkeR', 'c40efb3746a1c42955f7bec867c1893d', 'neftaligv92@gmail.com', '25', 'm', 0),
(2, 'luis enrique', '2f8e8864280f8db22a15c066c6aff513', 'luisenrique@tucartera.cu', '16', 'm', 0),
(3, 'luis enrique', 'bca703cf47e67c85dec6fc728e2b9485', 'luisenrique@tucartera.cu', '16', 'm', 0),
(4, 'Puchi', '416d89f9e39ef4e3b9eab54ae2da71cd', 'Puchi.eprfm.ma.rimed.cu', '17', 'm', 0),
(5, 'Puchi', 'b57ed5dc646b592b2ed2e859ef3d4294', 'Puchi.eprfm.ma.rimed.cu', '17', 'm', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
