<?php
$servidor="localhost";
$usuario="root";
$password="s3rv3reprfmsql";
$base="db_creating";

$con=mysqli_connect($servidor,$usuario,$password) or die ('error|No se pudo conectar a la base de datos');
mysqli_select_db($con,$base);

?>